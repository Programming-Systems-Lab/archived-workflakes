vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|08 Nov 2002 06:25:05 -0000
vti_extenderversion:SR|4.0.2.6513
