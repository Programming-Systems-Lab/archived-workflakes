using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.IO;

namespace SMTP_Client
{
	/// <summary>
	/// Summary description for Service1.
	/// </summary>
	//[WebService(Namespace="http://vesey.psl.cs.columbia.edu/SMTP_Client", Name="Service1")]
	[WebService]
	[SoapRpcService]
	public class Service1 : System.Web.Services.WebService
	{
		private SMTP_Client m_pSMTP_Client = null;
		private static string fromAdd = "ss1121@columbia.edu";
		private static string subject = "Hello...";
		private static string body = "You have been spammed!";

		public Service1()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
			m_pSMTP_Client = new SMTP_Client();
			m_pSMTP_Client.DnsServers = new string[]{"194.126.115.18","194.126.101.34"};
			m_pSMTP_Client.SmartHost = "send.columbia.edu";
			m_pSMTP_Client.UseSmartHost = true;
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion


		[WebMethod]
		[SoapRpcMethod]
		public string sendEmail(string param)
		{

			string[] toAdd = new String[1];
			toAdd[0] = param;
			Stream strm = null;
			MimeMessage mime = new MimeMessage(fromAdd,toAdd,subject,body);
			string mim = mime.Mime;

			strm = new MemoryStream(System.Text.Encoding.ASCII.GetBytes(mim));

			m_pSMTP_Client.BeginSend(toAdd,fromAdd,strm);
			return "Email Sent to:"+param;
		}

		[WebMethod]
		[SoapRpcMethod]
		public string setSenderEmail(string param)
		{
			fromAdd = param;
			return "Sender Email changed to: "+param;
		}

		[WebMethod]
		[SoapRpcMethod]
		public string setSubject(string param)
		{
			subject = param;
			return "Subject header has been changed to: "+param;
		}

		[WebMethod]
		[SoapRpcMethod]
		public string setBody(string param)
		{
			body = param;
			return "Email body has been changed to: "+param;
		}
	}
}
