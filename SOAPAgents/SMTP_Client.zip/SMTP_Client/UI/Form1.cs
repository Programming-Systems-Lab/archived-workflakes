using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;

namespace SMTP_Client
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private LumiSoft.UI.Controls.WEditBox m_pTo;
		private LumiSoft.UI.Controls.WLabel wLabel1;
		private LumiSoft.UI.Controls.WButton m_pSend;
		private LumiSoft.UI.Controls.WEditBox m_pFrom;
		private LumiSoft.UI.Controls.WEditBox m_pSubject;
		private LumiSoft.UI.Controls.WEditBox m_pBody;
		private LumiSoft.UI.Controls.WLabel wLabel2;
		private LumiSoft.UI.Controls.WLabel wLabel3;
		private LumiSoft.UI.Controls.WLabel wLabel4;
		private System.Windows.Forms.Panel panel1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private LumiSoft.UI.Controls.WListBox wListBox1;
		private System.Windows.Forms.ListView listView1;
		private System.Windows.Forms.ColumnHeader columnHeader1;
		private System.Windows.Forms.ColumnHeader columnHeader2;
		private System.Windows.Forms.ColumnHeader columnHeader3;
		private LumiSoft.UI.Controls.WLabel wLabel5;
		private LumiSoft.UI.Controls.WLabel wLabel6;
		private LumiSoft.UI.Controls.WCheckBox.WCheckBox m_pFromFile;

		private SMTP_Client m_pSMTP_Client = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			m_pSMTP_Client = new SMTP_Client(this);
			m_pSMTP_Client.DnsServers = new string[]{"194.126.115.18","194.126.101.34"};
			m_pSMTP_Client.SmartHost = "mail.neti.ee";
			m_pSMTP_Client.PartOfMessageIsSent += new SMTP_PartOfMessage_EventHandler(this.m_pSMTP_Client_OnPartOfMessageIsSent);
			m_pSMTP_Client.Error += new SMTP_Error_EventHandler(this.m_pSMTP_Client_OnError);
			m_pSMTP_Client.NewSendJob += new SMTP_SendJob_EventHandler(this.m_pSMTP_Client_OnNewSendJob);
			m_pSMTP_Client.SendJobCompleted += new SMTP_SendJob_EventHandler(this.m_pSMTP_Client_OnSendJobCompleted);

			PropertyGrid grid = new PropertyGrid();
			grid.Location = panel1.Location;
			grid.Size     = panel1.Size;
			grid.Visible  = true;
			panel1.Visible = false;

			this.Controls.Add(grid);

			grid.SelectedObject = m_pSMTP_Client;
		}

		#region function Dispose

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.m_pTo = new LumiSoft.UI.Controls.WEditBox();
			this.wLabel1 = new LumiSoft.UI.Controls.WLabel();
			this.m_pSend = new LumiSoft.UI.Controls.WButton();
			this.m_pFrom = new LumiSoft.UI.Controls.WEditBox();
			this.m_pSubject = new LumiSoft.UI.Controls.WEditBox();
			this.m_pBody = new LumiSoft.UI.Controls.WEditBox();
			this.wLabel2 = new LumiSoft.UI.Controls.WLabel();
			this.wLabel3 = new LumiSoft.UI.Controls.WLabel();
			this.wLabel4 = new LumiSoft.UI.Controls.WLabel();
			this.panel1 = new System.Windows.Forms.Panel();
			this.wListBox1 = new LumiSoft.UI.Controls.WListBox();
			this.listView1 = new System.Windows.Forms.ListView();
			this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
			this.wLabel5 = new LumiSoft.UI.Controls.WLabel();
			this.m_pFromFile = new LumiSoft.UI.Controls.WCheckBox.WCheckBox();
			this.wLabel6 = new LumiSoft.UI.Controls.WLabel();
			((System.ComponentModel.ISupportInitialize)(this.m_pTo)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.m_pSend)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.m_pFrom)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.m_pSubject)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.m_pBody)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.wListBox1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.m_pFromFile)).BeginInit();
			this.SuspendLayout();
			// 
			// m_pTo
			// 
			this.m_pTo.DecimalPlaces = 2;
			this.m_pTo.DecMaxValue = 999999999;
			this.m_pTo.DecMinValue = -999999999;
			this.m_pTo.Lines = new string[0];
			this.m_pTo.Location = new System.Drawing.Point(16, 40);
			this.m_pTo.Mask = LumiSoft.UI.Controls.WEditBox_Mask.Text;
			this.m_pTo.MaxLength = 32767;
			this.m_pTo.Multiline = true;
			this.m_pTo.Name = "m_pTo";
			this.m_pTo.PasswordChar = '\0';
			this.m_pTo.ReadOnly = false;
			this.m_pTo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.m_pTo.Size = new System.Drawing.Size(136, 32);
			this.m_pTo.TabIndex = 0;
			this.m_pTo.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.m_pTo.UseStaticViewStyle = false;
			this.m_pTo.ViewStyle.EditReadOnlyColor = System.Drawing.Color.White;
			// 
			// wLabel1
			// 
			this.wLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.wLabel1.Location = new System.Drawing.Point(16, 16);
			this.wLabel1.Name = "wLabel1";
			this.wLabel1.Size = new System.Drawing.Size(128, 24);
			this.wLabel1.TabIndex = 1;
			this.wLabel1.Text = "Recipients:";
			this.wLabel1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.wLabel1.UseStaticViewStyle = false;
			// 
			// m_pSend
			// 
			this.m_pSend.Location = new System.Drawing.Point(312, 24);
			this.m_pSend.Name = "m_pSend";
			this.m_pSend.Size = new System.Drawing.Size(80, 24);
			this.m_pSend.TabIndex = 2;
			this.m_pSend.Text = "Send";
			this.m_pSend.UseStaticViewStyle = false;
			this.m_pSend.ButtonPressed += new LumiSoft.UI.Controls.ButtonPressedEventHandler(this.m_pSend_ButtonPressed);
			// 
			// m_pFrom
			// 
			this.m_pFrom.DecimalPlaces = 2;
			this.m_pFrom.DecMaxValue = 999999999;
			this.m_pFrom.DecMinValue = -999999999;
			this.m_pFrom.Lines = new string[0];
			this.m_pFrom.Location = new System.Drawing.Point(16, 96);
			this.m_pFrom.Mask = LumiSoft.UI.Controls.WEditBox_Mask.Text;
			this.m_pFrom.MaxLength = 32767;
			this.m_pFrom.Multiline = false;
			this.m_pFrom.Name = "m_pFrom";
			this.m_pFrom.PasswordChar = '\0';
			this.m_pFrom.ReadOnly = false;
			this.m_pFrom.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.m_pFrom.Size = new System.Drawing.Size(136, 24);
			this.m_pFrom.TabIndex = 3;
			this.m_pFrom.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.m_pFrom.UseStaticViewStyle = false;
			this.m_pFrom.ViewStyle.EditReadOnlyColor = System.Drawing.Color.White;
			// 
			// m_pSubject
			// 
			this.m_pSubject.DecimalPlaces = 2;
			this.m_pSubject.DecMaxValue = 999999999;
			this.m_pSubject.DecMinValue = -999999999;
			this.m_pSubject.Lines = new string[0];
			this.m_pSubject.Location = new System.Drawing.Point(16, 144);
			this.m_pSubject.Mask = LumiSoft.UI.Controls.WEditBox_Mask.Text;
			this.m_pSubject.MaxLength = 32767;
			this.m_pSubject.Multiline = false;
			this.m_pSubject.Name = "m_pSubject";
			this.m_pSubject.PasswordChar = '\0';
			this.m_pSubject.ReadOnly = false;
			this.m_pSubject.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.m_pSubject.Size = new System.Drawing.Size(360, 24);
			this.m_pSubject.TabIndex = 4;
			this.m_pSubject.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.m_pSubject.UseStaticViewStyle = false;
			this.m_pSubject.ViewStyle.EditReadOnlyColor = System.Drawing.Color.White;
			// 
			// m_pBody
			// 
			this.m_pBody.DecimalPlaces = 2;
			this.m_pBody.DecMaxValue = 999999999;
			this.m_pBody.DecMinValue = -999999999;
			this.m_pBody.Lines = new string[0];
			this.m_pBody.Location = new System.Drawing.Point(16, 192);
			this.m_pBody.Mask = LumiSoft.UI.Controls.WEditBox_Mask.Text;
			this.m_pBody.MaxLength = 32767;
			this.m_pBody.Multiline = true;
			this.m_pBody.Name = "m_pBody";
			this.m_pBody.PasswordChar = '\0';
			this.m_pBody.ReadOnly = false;
			this.m_pBody.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.m_pBody.Size = new System.Drawing.Size(360, 80);
			this.m_pBody.TabIndex = 5;
			this.m_pBody.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.m_pBody.UseStaticViewStyle = false;
			this.m_pBody.ViewStyle.EditReadOnlyColor = System.Drawing.Color.White;
			// 
			// wLabel2
			// 
			this.wLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.wLabel2.Location = new System.Drawing.Point(16, 80);
			this.wLabel2.Name = "wLabel2";
			this.wLabel2.Size = new System.Drawing.Size(128, 16);
			this.wLabel2.TabIndex = 6;
			this.wLabel2.Text = "From:";
			this.wLabel2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.wLabel2.UseStaticViewStyle = false;
			// 
			// wLabel3
			// 
			this.wLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.wLabel3.Location = new System.Drawing.Point(16, 128);
			this.wLabel3.Name = "wLabel3";
			this.wLabel3.Size = new System.Drawing.Size(128, 16);
			this.wLabel3.TabIndex = 7;
			this.wLabel3.Text = "Subject:";
			this.wLabel3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.wLabel3.UseStaticViewStyle = false;
			// 
			// wLabel4
			// 
			this.wLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.wLabel4.Location = new System.Drawing.Point(16, 176);
			this.wLabel4.Name = "wLabel4";
			this.wLabel4.Size = new System.Drawing.Size(128, 16);
			this.wLabel4.TabIndex = 8;
			this.wLabel4.Text = "Body:";
			this.wLabel4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.wLabel4.UseStaticViewStyle = false;
			// 
			// panel1
			// 
			this.panel1.Location = new System.Drawing.Point(440, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(224, 280);
			this.panel1.TabIndex = 9;
			// 
			// wListBox1
			// 
			this.wListBox1.ItemHeight = 13;
			this.wListBox1.Location = new System.Drawing.Point(8, 296);
			this.wListBox1.Name = "wListBox1";
			this.wListBox1.Size = new System.Drawing.Size(296, 128);
			this.wListBox1.TabIndex = 12;
			this.wListBox1.UseStaticViewStyle = false;
			// 
			// listView1
			// 
			this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																						this.columnHeader1,
																						this.columnHeader2,
																						this.columnHeader3});
			this.listView1.FullRowSelect = true;
			this.listView1.Location = new System.Drawing.Point(312, 296);
			this.listView1.MultiSelect = false;
			this.listView1.Name = "listView1";
			this.listView1.Size = new System.Drawing.Size(344, 128);
			this.listView1.TabIndex = 13;
			this.listView1.View = System.Windows.Forms.View.Details;
			// 
			// columnHeader1
			// 
			this.columnHeader1.Text = "JobID";
			// 
			// columnHeader2
			// 
			this.columnHeader2.Text = "Status";
			// 
			// columnHeader3
			// 
			this.columnHeader3.Text = "Affected emails";
			this.columnHeader3.Width = 200;
			// 
			// wLabel5
			// 
			this.wLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.wLabel5.Location = new System.Drawing.Point(16, 280);
			this.wLabel5.Name = "wLabel5";
			this.wLabel5.Size = new System.Drawing.Size(200, 16);
			this.wLabel5.TabIndex = 14;
			this.wLabel5.Text = "Errors:";
			this.wLabel5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.wLabel5.UseStaticViewStyle = false;
			// 
			// m_pFromFile
			// 
			this.m_pFromFile.Checked = false;
			this.m_pFromFile.Location = new System.Drawing.Point(192, 80);
			this.m_pFromFile.Name = "m_pFromFile";
			this.m_pFromFile.ReadOnly = false;
			this.m_pFromFile.Size = new System.Drawing.Size(16, 16);
			this.m_pFromFile.TabIndex = 15;
			this.m_pFromFile.UseStaticViewStyle = false;
			this.m_pFromFile.ViewStyle.EditReadOnlyColor = System.Drawing.Color.White;
			this.m_pFromFile.CheckedChanged += new System.EventHandler(this.m_pFromFile_CheckedChanged);
			// 
			// wLabel6
			// 
			this.wLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.wLabel6.Location = new System.Drawing.Point(216, 80);
			this.wLabel6.Name = "wLabel6";
			this.wLabel6.Size = new System.Drawing.Size(144, 24);
			this.wLabel6.TabIndex = 16;
			this.wLabel6.Text = "Load message from file";
			this.wLabel6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.wLabel6.UseStaticViewStyle = false;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(664, 445);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.wLabel6,
																		  this.m_pFromFile,
																		  this.wLabel5,
																		  this.listView1,
																		  this.wListBox1,
																		  this.panel1,
																		  this.wLabel4,
																		  this.wLabel3,
																		  this.wLabel2,
																		  this.m_pBody,
																		  this.m_pSubject,
																		  this.m_pFrom,
																		  this.m_pSend,
																		  this.wLabel1,
																		  this.m_pTo});
			this.Name = "Form1";
			this.Text = "Form1";
			((System.ComponentModel.ISupportInitialize)(this.m_pTo)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.m_pSend)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.m_pFrom)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.m_pSubject)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.m_pBody)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.wListBox1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.m_pFromFile)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}


		#region Events handling

		private void m_pSMTP_Client_OnPartOfMessageIsSent(object sender,PartOfMessage_EventArgs e)
		{
			foreach(ListViewItem it in listView1.Items){
				if(it.Text == e.JobID){
					it.SubItems[1].Text = Convert.ToString(((int)(e.TotalSent*100)/e.MessageSize)) + "%";
					break;
				}
			}
		}

		private void m_pSMTP_Client_OnError(object sender,SMTP_Error e)
		{
			wListBox1.Items.Add(e.ErrorText);
		}

		private void m_pSMTP_Client_OnNewSendJob(object sender,SendJob_EventArgs e)
		{	
			ListViewItem it = new ListViewItem();
			it.Text = e.JobID;
			it.SubItems.Add("0");
			it.SubItems.Add("");
			it.SubItems[2].Text = e.To[0];
			listView1.Items.Add(it);
		}

		private void m_pSMTP_Client_OnSendJobCompleted(object sender,SendJob_EventArgs e)
		{	
			foreach(ListViewItem it in listView1.Items){
				if(it.Text == e.JobID){
					it.Remove();
					break;
				}
			}
		}

		private void m_pSend_ButtonPressed(object sender, System.EventArgs e)
		{			
			listView1.Items.Clear();
			wListBox1.Items.Clear();

			Stream strm = null;
			if(m_pFromFile.Checked){
				strm = File.OpenRead("test.eml");
			}
			else{
				MimeMessage mime = new MimeMessage(m_pFrom.Text,m_pTo.Lines,m_pSubject.Text,m_pBody.Text);
				string mim = mime.Mime;

				strm = new MemoryStream(System.Text.Encoding.ASCII.GetBytes(mim));
			}

			m_pSMTP_Client.BeginSend(m_pTo.Lines,m_pFrom.Text,strm);
		}

		private void m_pFromFile_CheckedChanged(object sender, System.EventArgs e)
		{
			if(m_pFromFile.Checked){
				m_pSubject.Enabled = false;
				m_pBody.Enabled    = false;
			}
			else{
				m_pSubject.Enabled = true;
				m_pBody.Enabled    = true;
			}
		}

		#endregion

		
	}
}
