using System;
using System.IO;
using System.Net;
using System.Net.Sockets;

namespace SMTP_Client
{
	/// <summary>
	/// Summary description for Core.
	/// </summary>
	public class Core
	{
		public Core()
		{			
		}

		#region function DoPeriodHandling

		public static MemoryStream DoPeriodHandling(byte[] data,bool add_Remove)
		{
			using(MemoryStream strm = new MemoryStream(data)){
				return DoPeriodHandling(strm,add_Remove);
			}
		}

		/// <summary>
		/// Does period handling.
		/// </summary>
		/// <param name="strm">Input stream.</param>
		/// <param name="add_Remove">If true add periods, else removes periods.</param>
		/// <returns></returns>
		public static MemoryStream DoPeriodHandling(Stream strm,bool add_Remove)
		{
			try
			{
				MemoryStream mhStrm = new MemoryStream();
				
				strm.Position = 0;
				StreamReader reader = new StreamReader(strm);
				string line = reader.ReadLine();

				// Loop through all lines
				while(line != null){						
					if(line.StartsWith(".")){
						// Add period							
						if(add_Remove){
							line = "." + line;
						}
						/*
						 If the first character is a
						 period and there are other characters on the line, the first characteris deleted.							
						*/
						else if(line.Length > 1){
							line = line.Substring(1);
						}
					}

					byte[] data = System.Text.Encoding.ASCII.GetBytes(line + "\r\n");
					mhStrm.Write(data,0,data.Length);

					// Read next line
					line = reader.ReadLine();
				}

				mhStrm.Position = 0;
				return mhStrm;				
			}
			catch(Exception x)
			{
			//	Core.WriteLog("e:\\aa.log",x.Message); 
			}
			
			return null;
		}

		#endregion
	}
}
