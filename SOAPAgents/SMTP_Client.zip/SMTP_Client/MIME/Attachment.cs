using System;

namespace SMTP_Client
{
	/// <summary>
	/// Attachment.
	/// </summary>
	public class Attachment
	{
		private string m_FileName       = "";
		private byte[] m_FileData       = null;
		private string m_AttachmentType = "";

		public Attachment(string fileName)
		{
			m_AttachmentType = "file";

			m_FileName = fileName;
		}

		public Attachment(string fileName,byte[] fileData)
		{
			m_AttachmentType = "data";

			m_FileName = fileName;
			m_FileData = fileData;
		}


		#region Properties Implementation

		public string FileName
		{
			get{ return m_FileName;	}
		}

		public byte[] FileData
		{
			get{ return m_FileData;	}
		}

		public string AttachmentType
		{
			get{ return m_AttachmentType; }
		}

		#endregion

	}
}
