using System;
using System.Collections;
using System.ComponentModel;

namespace SMTP_Client
{
	/// <summary>
	/// Attachments collection.
	/// </summary>
	public class Attachments : ArrayList
	{
		public Attachments()
		{
		}

		public int Add(Attachment attachment)
		{	
			return base.Add(attachment);
		}

		public new Attachment this[int nIndex] 
		{ 
			get{ return (Attachment)base[nIndex]; }

			set{
				base[nIndex] = value;
			}
		}

	}
}
