using System;
using System.IO;
using System.Net;
using System.Threading;
using System.Collections;
using System.Net.Sockets;
using System.Windows.Forms;
using LumiSoft.Net.Dns;

namespace SMTP_Client
{
	#region enum SMTP_ErrorType

	/// <summary>
	/// SMTP error types.
	/// </summary>
	public enum SMTP_ErrorType
	{
		/// <summary>
		/// Connection related error.
		/// </summary>
		ConnectionError = 1,

		/// <summary>
		/// Email address doesn't exist.
		/// </summary>
		InvalidEmailAddress = 2,

		/// <summary>
		/// Unknown error.
		/// </summary>
		UnKnown = 256,
	}

	#endregion


	/// <summary>
	/// 
	/// </summary>
	public delegate void SMTP_Error_EventHandler(object sender,SMTP_Error e);

	/// <summary>
	/// 
	/// </summary>
	public delegate void SMTP_PartOfMessage_EventHandler(object sender,PartOfMessage_EventArgs e);

	/// <summary>
	/// 
	/// </summary>
	public delegate void SMTP_SendJob_EventHandler(object sender,SendJob_EventArgs e);

	/// <summary>
	/// Simple SMTP_Client.
	/// </summary>
	public class SMTP_Client
	{
		private string    m_SmartHost    = "";
		private string[]  m_DnsServers   = null;
		private bool      m_UseSmartHost = false;
		private int       m_Port         = 25;
		private int       m_MaxThreads   = 10;
		private int       m_SendTimeOut  = 30000;
		private ArrayList m_pErrors      = null;
		private Hashtable m_SendTrTable  = null;
		private Control   m_pOwnerUI     = null;
		private object[]  m_Params       = null;


		#region Events declarations

		/// <summary>
		/// Is raised when some send jobs message part is sent.
		/// </summary>
		public event SMTP_PartOfMessage_EventHandler PartOfMessageIsSent = null;

		/// <summary>
		/// Is raised when new send job starts.
		/// </summary>
		public event SMTP_SendJob_EventHandler NewSendJob = null;

		/// <summary>
		/// Is raised when send job completes.
		/// </summary>
		public event SMTP_SendJob_EventHandler SendJobCompleted = null;

		/// <summary>
		/// Is raised when error occurs.
		/// </summary>
		public event SMTP_Error_EventHandler Error = null;

		#endregion


		/// <summary>
		/// Default constructor.
		/// </summary>
		public SMTP_Client() : this(null)
		{
		}

		/// <summary>
		/// Use this constructor if you use this component on UI component.
		/// NOTE: Events are invoked on UI Thread.
		/// </summary>
		/// <param name="ownerUI"></param>
		public SMTP_Client(Control ownerUI)
		{	
			m_pOwnerUI    = ownerUI;
			m_pErrors     = new ArrayList();
			m_SendTrTable = new Hashtable();
		}


		#region function BeginSend

		/// <summary>
		/// Starts asynchronous sending.
		/// </summary>
		/// <param name="to">Recipients, may be from different e-domain when using dns or relay is allowed in smart host.</param>
		/// <param name="from">Sendres email address.</param>
		/// <param name="message">Stream which contains message. NOTE: reading from stream is started from stream current position.</param>
		public void BeginSend(string[] to,string from,Stream message)
		{	
			// Clear old errors
			m_pErrors.Clear();

			m_Params = new object[]{to,from,message};

			// Start new thread for send controller
			Thread t = new Thread(new ThreadStart(this.BeginSend));	
			t.Start();
		}

		/// <summary>
		/// This function just controls sending.
		/// </summary>
		private void BeginSend()
		{
			string[] to    = (string[])m_Params[0];
			string from    = (string)m_Params[1];
			Stream message = (Stream)m_Params[2];
			

			// Check to if same e-domians(same server). Eg. ivx@lumisoft.ee, xxx@lumisoft.ee
			// If not, group same e-domians and send them appropiate server. Eg. ivx@lumisoft.ee, aa@ve.ee
			// This approach avoids sending message multiple times to same server.
			// Eg. we have ivx@lumisoft.ee, xxx@lumisoft.ee,  aa@ve.ee
			// Then we must send ivx@lumisoft.ee, xxx@lumisoft.ee - to lumisoft server
			//					 aa@ve.ee - to ve server

			Hashtable rcptPerServer = new Hashtable();
			foreach(string rcpt in to){
				string eDomain = rcpt.Substring(rcpt.IndexOf("@"));//*******
				if(rcptPerServer.Contains(eDomain)){
					// User eAddress is in same server
					ArrayList sameServerEaddresses = (ArrayList)rcptPerServer[eDomain];
					sameServerEaddresses.Add(rcpt);
				}
				else{
					ArrayList sameServerEaddresses = new ArrayList();
					sameServerEaddresses.Add(rcpt);
					rcptPerServer.Add(eDomain,sameServerEaddresses);
				}
			}

			// Loop through the list of servers where we must send messages
			foreach(ArrayList sameServerEaddresses in rcptPerServer.Values){
				string[] rcpts = new string[sameServerEaddresses.Count];
				sameServerEaddresses.CopyTo(rcpts);

				//----- Create copy of message ------------------------------------//
				// We neeed this, because otherwise multible Threads access Stream.
				long pos = message.Position;
				byte[] dataBuf = new byte[message.Length - message.Position];
				message.Read(dataBuf,0,(int)(message.Length - message.Position));
				MemoryStream messageCopy = new MemoryStream(dataBuf);
				message.Position = pos;

				// Start new thread for sending
				Thread t = new Thread(new ThreadStart(this.StartSendJob));					
				m_SendTrTable.Add(t,new object[]{rcpts,from,messageCopy});
				t.Start();
					
				//If maximum sender threads are exceeded,
				//wait when some gets available.
				while(m_SendTrTable.Count > m_MaxThreads){
					Thread.Sleep(100);
				}
			}
		}

		#endregion

		#region function Send

	//	public bool Send(string[] to,string from,MemoryStream message)
	//	{
	//		return true;
	//	}

		#endregion


		#region function StartSendJob

		private void StartSendJob()
		{
			try
			{
				if(!m_SendTrTable.Contains(Thread.CurrentThread)){
					return;
				}
								
				// Get params from Hashtable
				object[] param = (object[])m_SendTrTable[Thread.CurrentThread];

				// Raise event
				OnNewSendJobStarted(Thread.CurrentThread.GetHashCode().ToString(),(string[])param[0]);

				// Send message to specified server
				SendMessageToServer((string[])param[0],(string)param[1],(Stream)param[2]);

				// Raise event
				OnSendJobCompleted(Thread.CurrentThread.GetHashCode().ToString(),(string[])param[0]);
			}
			catch{
			}
			finally{
				RemoveSenderThread(Thread.CurrentThread);
			}
		}

		#endregion

		#region function RemoveThread

		/// <summary>
		/// Removes sender Thread - Thread has finnished sending.
		/// </summary>
		/// <param name="t"></param>
		private void RemoveSenderThread(Thread t)
		{
			lock(m_SendTrTable){				
				if(!m_SendTrTable.ContainsKey(t)){
					return;
				}
				m_SendTrTable.Remove(t);				
			}
		}

		#endregion


		//---- SMTP implementation ----//

		#region function SendMessageToServer

		private bool SendMessageToServer(string[] to,string reverse_path,Stream message)
		{
			try
			{
				string reply = "";

				TcpClient smtpClnt = null;
				if(m_UseSmartHost){
					smtpClnt = new TcpClient(m_SmartHost,m_Port);
				}
				else{
					string domain = to[0];
					if(domain.IndexOf("@") > -1){
						domain = to[0].Substring(to[0].LastIndexOf("@")+1);
					}

					DnsEx dns = new DnsEx();
					DnsEx.DnsServers = m_DnsServers;
					MX_Record[] mxRecords = null;
					DnsReplyCode replyCode = dns.GetMXRecords(domain,out mxRecords);
					if(replyCode == DnsReplyCode.Ok){
						string host = mxRecords[0].Host;

						smtpClnt = new TcpClient(host,m_Port);
					}
					else if(replyCode == DnsReplyCode.NoEntries){
						OnError(SMTP_ErrorType.InvalidEmailAddress,to,"email domain <" + domain + "> is invalid");
						return false;
					}
				}				
							
				// Get response stream from server
				NetworkStream strm = smtpClnt.GetStream();


				#region Get 220 reply from server 

				// Server must reply 220 - Server OK
				reply = ReadReply(strm);				
				if(!IsReplyCode("220",reply)){
					OnError(SMTP_ErrorType.UnKnown,to,reply);
					SendData("QUIT\r\n",strm);
					return false;
				}

				#endregion


				#region cmd EHLO
			
				// Send greeting to server
				SendData("EHLO " + Dns.GetHostName() + "\r\n",strm);

				reply = ReadReply(strm);
				if(!IsReplyCode("250 ",reply)){
					OnError(SMTP_ErrorType.UnKnown,to,reply);
					SendData("QUIT\r\n",strm);
					return false;
				}
				// Must handle multi line response
				// Check if auth is allowed

				#endregion

				#region cmd MAIL

				// Send Mail From
				SendData("MAIL FROM:" + reverse_path + "\r\n",strm);

				reply = ReadReply(strm);
				if(!IsReplyCode("250",reply)){
					OnError(SMTP_ErrorType.UnKnown,to,reply);
					SendData("QUIT\r\n",strm);
					return false;
				}

				#endregion

				#region cmd RCPT
				
				bool isAnyValidEmail = false;
				foreach(string rcpt in to){
					// Send Mail To
					SendData("RCPT TO:" + rcpt + "\r\n",strm);

					reply = ReadReply(strm);
					if(!IsReplyCode("250",reply)){

						// Is unknown user
						if(IsReplyCode("550",reply)){
							// ToDo rcpt must be removed from affected list
							OnError(SMTP_ErrorType.InvalidEmailAddress,to,reply);
						}
						else{
							OnError(SMTP_ErrorType.UnKnown,to,reply);
						}					
					}
					else{
						isAnyValidEmail = true;
					}
				}

				// If there isn't any valid email - quit.
				if(!isAnyValidEmail){
					SendData("QUIT\r\n",strm);
					return false;
				}
				//---------------------------------------------//

				#endregion

				#region cmd DATA

				//-------------- Data - Send Mime ---------------------------------//

				// Notify Data Start
				SendData("DATA\r\n",strm);

				reply = ReadReply(strm);
				if(!IsReplyCode("354",reply)){
					OnError(SMTP_ErrorType.UnKnown,to,reply);
					SendData("QUIT\r\n",strm);
					return false;
				}
			
				//------- Do period handling -----------------------------------------//
				// If line starts with '.', add additional '.'.(Read rfc for more info)
				message = Core.DoPeriodHandling(message,true);
				//--------------------------------------------------------------------//
			
				long totalSent = 0;
				while(message.Position < message.Length){
					int blockSize = 4024;
					byte[] dataBuf = new byte[blockSize];
					int nCount = message.Read(dataBuf,0,blockSize);
					strm.Write(dataBuf,0,nCount);

					totalSent += nCount;

					OnPartOfMessageIsSent(blockSize,totalSent,message.Length);
				}
		
				// Notify End of Data
				SendData("\r\n.\r\n",strm);

				reply = ReadReply(strm);
				if(!IsReplyCode("250",reply)){
					OnError(SMTP_ErrorType.UnKnown,to,reply);
					SendData("QUIT\r\n",strm);
					return false;
				}
				//-------------------------------------------------------------------//

				#endregion

				#region cmd QUIT

				// Notify server - server can exit now
				SendData("QUIT\r\n",strm);

				#endregion

			}
			catch(Exception x)
			{
				OnError(SMTP_ErrorType.ConnectionError,to,x.Message);
			}

			return true;
		}

		#endregion

		#region function IsReplyCode

		/// <summary>
		/// Checks if reply code.
		/// </summary>
		/// <param name="replyCode">Replay code to check.</param>
		/// <param name="reply">Full repaly.</param>
		/// <returns>Retruns true if reply is as specified.</returns>
		private bool IsReplyCode(string replyCode,string reply)
		{
			if(reply.IndexOf(replyCode) > -1){
				return true;
			}
			else{
				return false;
			}
		}

		#endregion

		#region function ReadReply

		private string ReadReply(NetworkStream stream)
		{
			try
			{
				bool ok = false;
				int  sTime = Environment.TickCount;
				MemoryStream strm = new MemoryStream();

				while(true)
				{
					if(stream.DataAvailable){
						byte[] repl = new byte[1024];
						int nCount = stream.Read(repl,0,1024);
						strm.Seek(0,SeekOrigin.Begin);
						strm.Write(repl,0,nCount);

						//---- Check for terminator ------------------//
						if(!stream.DataAvailable && strm.Length >= 2){
							byte[] bufComp = new byte[2];
							strm.Position = strm.Length - 2;
							strm.Read(bufComp,0,2);

							string strCompare = System.Text.Encoding.ASCII.GetString(bufComp);
														               				
							// <CRLF> - means end of reply
							if(strCompare.IndexOf("\r\n") > -1){
								ok = true;
								break;
							}
						}
						//---------------------------------------------//

						sTime = Environment.TickCount;
					}
				
					//---- Time out stuff -----------------------//
					if(!stream.DataAvailable){
						if(Environment.TickCount > sTime + 20000){
							break;
						}					
						System.Threading.Thread.Sleep(30);					
					}				
					//------------------------------------------//
				}

				byte[] byte_reply = strm.ToArray();
				strm.Close();

				string reply = System.Text.Encoding.ASCII.GetString(byte_reply);
				if(ok){
					return reply;
				}				
			}
			catch(Exception x)
			{
	//			Core.WriteLog("c:\\SMTP_Send.err","ReadReply:" + x.Message);
			}

			return "";
		}

		#endregion		

		#region function SendData
		
		private void SendData(string data,NetworkStream strm)
		{	
			try
			{				
				byte[] byte_data = System.Text.Encoding.ASCII.GetBytes(data.ToCharArray());
				strm.Write(byte_data,0,byte_data.Length);	
			}
			catch(Exception x)
			{
		//		Core.WriteLog("c:\\SMTP_Send.err","SendData:" + x.Message);
			}
		}

		#endregion

		//----------------------------//


		#region Properties Implementation

		/// <summary>
		/// Gets or sets smart host. Eg. 'mail.yourserver.net'.
		/// </summary>
		public string SmartHost
		{
			get{ return m_SmartHost; }

			set{ m_SmartHost = value; }
		}

		/// <summary>
		/// Gets or sets dns servers(IP addresses).
		/// </summary>
		public string[] DnsServers
		{
			get{ return m_DnsServers; }
			
			set{ m_DnsServers = value; }
		}

		/// <summary>
		/// Gets or sets if mail is sent through smart host or using dns.
		/// </summary>
		public bool UseSmartHost
		{
			get{ return m_UseSmartHost; }

			set{ m_UseSmartHost = value; }
		}

		/// <summary>
		/// Gets or sets SMTP port.
		/// </summary>
		public int Port
		{
			get{ return m_Port; }

			set{ m_Port = value; }
		}

		/// <summary>
		/// Gets or sets maximum sender Threads.
		/// </summary>
		public int MaxSenderThreads
		{
			get{ return m_MaxThreads; }

			set{
				if(value < 1){
					m_MaxThreads = 1; 
				}
				else{
					m_MaxThreads = value; 
				}
			}
		}

		/// <summary>
		/// Gets last send attempt errors.
		/// </summary>
		public SMTP_Error[] Errors
		{
			get{ 
				SMTP_Error[] errors = new SMTP_Error[m_pErrors.Count];
				m_pErrors.CopyTo(errors);

				return errors;
			}
		}

		/// <summary>
		/// Gets if some send job is active.
		/// </summary>
		public bool IsSending
		{
			get{
				if(m_SendTrTable.Count > 0){
					return true;
				}				
				return false;
			}
		}

		#endregion

		#region Events Implementation

		#region function OnPartOfMessageIsSent

		protected void OnPartOfMessageIsSent(long sentBlockSize,long totalSent,long messageSize)
		{			
			if(this.PartOfMessageIsSent != null){
				string jobID = Thread.CurrentThread.GetHashCode().ToString();
				if(m_pOwnerUI == null){
					this.PartOfMessageIsSent(this,new PartOfMessage_EventArgs(jobID,sentBlockSize,totalSent,messageSize));
				}
				// For UI we must use invoke, because UI doesn't support multi Threading.
				else{
					m_pOwnerUI.Invoke(this.PartOfMessageIsSent,new object[]{this,new PartOfMessage_EventArgs(jobID,sentBlockSize,totalSent,messageSize)});
				}
			}
		}

		#endregion

		#region function OnNewSendJobStarted

		protected void OnNewSendJobStarted(string jobID,string[] to)
		{
			if(this.NewSendJob != null){
				if(m_pOwnerUI == null){
					this.NewSendJob(this,new SendJob_EventArgs(jobID,to));
				}
				// For UI we must use invoke, because UI doesn't support multi Threading.
				else{
					m_pOwnerUI.Invoke(this.NewSendJob,new object[]{this,new SendJob_EventArgs(jobID,to)});
				}
			}
		}

		#endregion

		#region function OnSendJobCompleted

		protected void OnSendJobCompleted(string jobID,string[] to)
		{
			if(this.SendJobCompleted != null){
				if(m_pOwnerUI == null){
					this.SendJobCompleted(this,new SendJob_EventArgs(jobID,to));
				}
				// For UI we must use invoke, because UI doesn't support multi Threading.
				else{
					m_pOwnerUI.Invoke(this.SendJobCompleted,new object[]{this,new SendJob_EventArgs(jobID,to)});
				}
			}
		}

		#endregion

		#region function OnError

		/// <summary>
		/// Raises error event.
		/// </summary>
		/// <param name="type">Error type.</param>
		/// <param name="affectedAddresses">Affected email addresses.</param>
		/// <param name="errorText">Error text.</param>
		protected void OnError(SMTP_ErrorType type,string[] affectedAddresses,string errorText)
		{
			// we must lock write(add), becuse multiple Threads may raise OnError same time.
			lock(m_pErrors){
				m_pErrors.Add(new SMTP_Error(type,affectedAddresses,errorText));
			}

			if(this.Error != null){
				if(m_pOwnerUI == null){
					this.Error(this,new SMTP_Error(type,affectedAddresses,errorText));
				}
				// For UI we must use invoke, because UI doesn't support multi Threading.
				else{
					m_pOwnerUI.Invoke(this.Error,new object[]{this,new SMTP_Error(type,affectedAddresses,errorText)});
				}
			}
		}

		#endregion

		#endregion

	}
}
