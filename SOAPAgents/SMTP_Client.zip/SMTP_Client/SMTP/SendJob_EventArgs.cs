using System;

namespace SMTP_Client
{
	/// <summary>
	/// Summary description for SendJob_Eventargs.
	/// </summary>
	public class SendJob_EventArgs
	{
		private string   m_JobID = "";
		private string[] m_To    = null; 

		public SendJob_EventArgs(string jobID,string[] to)
		{	
			m_JobID = jobID;
			m_To    = to;
		}


		#region Properties Implementation

		/// <summary>
		/// Gets send job ID.
		/// </summary>
		public string JobID
		{
			get{ return m_JobID; }
		}

		/// <summary>
		/// Gets this send job's email addresses.
		/// </summary>
		public string[] To
		{
			get{ return m_To; }
		}

		#endregion

	}
}
